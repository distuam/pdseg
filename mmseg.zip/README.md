# pdseg
Plant disease segmentation
